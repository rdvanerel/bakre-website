Plugins
=======

By default, the jCarousel core only contains the minimum functionality needed to
built carousel widgets. Specialized features are provided through plugins.

jCarousel comes with the following plugins:

* [Control Plugin](control/)
* [Pagination Plugin](pagination/)
* [Autoscroll Plugin](autoscroll/)
* [ScrollIntoView Plugin](scrollintoview/)
